// #include "tokenizer.h"



// Tokenizer::Tokenizer(){}
// Tokenizer::Tokenizer(std::string string){
//     _tk_str = string;
// }

// void Tokenizer::set_string(string str){
//     _tk_str = str;
// }

// void Tokenizer::set_ST(STATES new_ST){
//     _prev_ST = _curr_ST;
//     _curr_ST = new_ST;
// }

// TOKEN_TYPES Tokenizer::get_type(STATES cur_ST){

// }




// void Tokenizer::toekn(){
//     _wlk = _tk_str.begin();
//     while(*_wlk != '\0'){
//         _token._type = get_type(_curr_ST);


//         _wlk++;
//     }
// }